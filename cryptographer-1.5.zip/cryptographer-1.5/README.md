Use system command to install dependencies:

"pip3 install -r requirements.txt" or "pip install -r requirements.txt

---
**List of ciphers and functions:**

1. BASE64 - encode_base_64
2. BASE32 - encode_base_32
3. BASE16 - encode_base_16
4. HEX - encode_hex
5. URLENCODE - encode_urlencode
6. ROT13 - encode_rot13
7. MD5 - encode_md5
8. SHA-1 - encode_sha_1
9. SHA-256 - encode_sha_256
10. SHA-512 - encode_sha_512
---
**Using of argument in functions is required!** 

---
**Example for importing and using script:**

```python
from cryptography.base_64 import encode_base_64 # import encoder

print(encode_base_64("hello_world")) # print result of function "encode_base_64"
```

**Output:**
```commandline
aGVsbG9fd29ybGQ=

Process finished with exit code 0
```

