from distutils.core import setup

setup(
    name="cryptographer",
    version="1.5",
    description="cryptography module",
    author="Serg",
    packages=[".", "cryptography"]
)
