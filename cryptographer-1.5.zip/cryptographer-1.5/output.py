from user_input import user_text


def write_to_file(my_dic):
    message = user_text()
    with open("res_ ciphers.txt", "w") as file:
        file.write(f"Text: {message}")
        for key in enumerate(my_dic.keys()):
            if key[0] != 0:
                file.write("\n" + "-" * 35 + "\n")
                file.write(f"{key[0]}. {key[1]}\n")
                file.write("-" * 35 + "\n")
                file.writelines(my_dic[key[1]](message))
    print("Done!")


def output_result(my_dic, num):
    for key in enumerate(my_dic.keys()):
        if key[0] == num:
            if key[0] == 0:
                exit()
            else:
                print("-" * 35)
                print(*key, sep=". ")
                print("-" * 35)
                print(f"MD5\t\t ==>  "
                      f"{my_dic[key[1]](user_text())}")
