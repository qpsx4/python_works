from logo_menu import print_logo, print_menu
from user_input import select_number
from output import write_to_file, output_result
from cryptography.base_64 import encode_base_64
from cryptography.base_32 import encode_base_32
from cryptography.base_16 import encode_base_16
from cryptography.hex import encode_hex
from cryptography.md5 import encode_md5
from cryptography.rot13 import encode_rot13
from cryptography.urlencode import encode_urlencode
from cryptography.sha_1 import encode_sha_1
from cryptography.sha_256 import encode_sha_256
from cryptography.sha_512 import encode_sha_512


if __name__ == "__main__":
    my_dic = {
        "Exit": "pass",
        "BASE64": encode_base_64,
        "BASE32": encode_base_32,
        "BASE16": encode_base_16,
        "HEX": encode_hex,
        "URLENCODE": encode_urlencode,
        "ROT13": encode_rot13,
        "MD5": encode_md5,
        "SHA-1": encode_sha_1,
        "SHA-256": encode_sha_256,
        "SHA-512": encode_sha_512
    }

    print_logo()
    print_menu()

    while (num := select_number()) == 11:
        write_to_file(my_dic)
        break
    else:
        output_result(my_dic, num)
