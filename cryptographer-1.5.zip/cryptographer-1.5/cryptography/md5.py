import hashlib


def encode_md5(txt):
    return hashlib.md5(txt.encode()).hexdigest()
