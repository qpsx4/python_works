import base64


def encode_base_32(txt):
    txt_byt = bytes(txt, 'utf-8')
    return base64.b32encode(txt_byt).decode()