import hashlib


def encode_sha_256(txt):
    return hashlib.sha256(txt.encode()).hexdigest()
