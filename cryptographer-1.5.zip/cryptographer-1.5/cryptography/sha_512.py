import hashlib


def encode_sha_512(txt):
    return hashlib.sha512(txt.encode()).hexdigest()
