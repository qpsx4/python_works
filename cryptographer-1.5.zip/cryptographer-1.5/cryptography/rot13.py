import codecs


def encode_rot13(txt):
    return codecs.encode(txt, 'rot_13')
