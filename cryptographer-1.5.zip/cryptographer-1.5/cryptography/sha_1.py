import hashlib


def encode_sha_1(txt):
    return hashlib.sha1(txt.encode()).hexdigest()
