import urllib.parse


def encode_urlencode(txt):
    res = urllib.parse.quote(txt)
    return res