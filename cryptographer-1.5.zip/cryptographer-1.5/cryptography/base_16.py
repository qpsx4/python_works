import base64


def encode_base_16(txt):
    txt_byt = bytes(txt, 'utf-8')
    return base64.b16encode(txt_byt).decode()