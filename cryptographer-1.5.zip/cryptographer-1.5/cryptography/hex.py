def encode_hex(txt):
    return '\\' + '\\'.join(hex(ord(c))[1:] for c in txt)
