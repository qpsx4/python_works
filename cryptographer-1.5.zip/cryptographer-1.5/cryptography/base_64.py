import base64


def encode_base_64(txt):
    txt_byt = bytes(txt, 'utf-8')
    return base64.b64encode(txt_byt).decode()