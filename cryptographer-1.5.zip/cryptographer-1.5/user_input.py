def user_text():
    try:
        usr_text = input("Enter text: ")
    except KeyboardInterrupt:
        print("\n\nStopped by user!")
        exit()
    else:
        return usr_text


def select_number():
    try:
        num = int(input("\nSelect number: "))
        if not 0 <= num <= 11:
            print("Error! Enter a number from 0 to 11")
            return 0
    except ValueError as ve:
        print(ve)
        return 0
    except KeyboardInterrupt:
        print("\n\nStopped by user!")
        return 0
    else:
        return num
