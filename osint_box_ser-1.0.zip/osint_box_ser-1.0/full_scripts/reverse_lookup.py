import requests
import socket


def reverse(address):
    try:
        remote_ip = socket.gethostbyname(address)
    except Exception as e:
        print(e)
        return
    try:
        res = requests.get(f"https://dns-history.whoisxmlapi.com/api/v1?apiKey=at_sqKIXAxjuPcOixyVfoVSFf7P9QtbF&ip={remote_ip}",
                       timeout=10)
    except requests.exceptions.Timeout:
        return "Timeout error"
    else:
        my_list = res.json()["result"]
        res_list = []
        for elem in my_list:
            res_list.append(f"{elem['name']}\n")
        return res_list
