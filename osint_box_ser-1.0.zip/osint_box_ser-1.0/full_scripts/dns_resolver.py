import dns.resolver


def search_mx(address):
    my_resolver = dns.resolver.Resolver(configure=False)

    my_resolver.nameservers = ['8.8.8.8', '1.1.1.1']
    try:
        answers = my_resolver.resolve(address, 'MX')
    except Exception as e:
        print(e)
    else:
        my_list = []
        for rdata in answers:
            my_list.append("MX Record: " + str(rdata.exchange) + "\n")
        return my_list
