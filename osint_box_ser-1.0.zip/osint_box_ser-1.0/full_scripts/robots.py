import requests


def get_page_data(html):
    res = html.text
    return res


def search_robots(url):
    head = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"}
    try:
        if not url.startswith("https://"):
            url = "https://" + url
        if url[-1] == '/':
            page = requests.get(url + "robots.txt", headers=head)
        else:
            page = requests.get(url + "/robots.txt", headers=head)
    except Exception as e:
        print(e)
    else:
        if page.status_code != 404:
            return get_page_data(page)
        else:
            return 'File "Robots.txt" bot found!'
