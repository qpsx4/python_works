def input_user():
    try:
        address = input("Enter domain or ip: ")
    except KeyboardInterrupt:
        print("\n\nStopped by user!")
        return exit()
    else:
        return address
