import pygeoip
import os
import socket


def location(ip):
    my_path = os.path.split(os.path.abspath(__file__))[0]
    if os.path.exists(new_path := (my_path + "/GeoIPCity.dat")):
        gi = pygeoip.GeoIP(new_path)
    else:
        print("File GeoIPCity.dat not found")
        return 0
    try:
        city = gi.record_by_addr(socket.gethostbyname(ip))
    except Exception as e:
        print(e)
    else:
        if not city is None:
            my_list = []
            for key in city:
                if city[key] is None or city[key] == 0:
                    continue
                else:
                    my_list.append(f"{key}: {city[key]}\n")
            return my_list
