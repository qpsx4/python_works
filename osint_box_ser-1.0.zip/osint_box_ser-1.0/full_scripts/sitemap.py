import requests
from bs4 import BeautifulSoup


def get_page_data(html):
    res = BeautifulSoup(html.text, 'lxml')
    line = res.find_all("loc")
    my_list = []
    for i in line:
        my_list.append(i.text + "\n")
    return my_list


def search_sitemap(url):
    try:
        if not url.startswith("https://"):
            url = "https://" + url
        if url[-1] == '/':
            page = requests.get(url + "sitemap.xml")
        else:
            page = requests.get(url + "/sitemap.xml")
    except Exception as e:
        print(e)
    else:
        if page.status_code == 200:
            return get_page_data(page)
        else:
            return 'File "sitemap.xml" bot found!'
