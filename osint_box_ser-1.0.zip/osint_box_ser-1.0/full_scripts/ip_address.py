import socket


def address(host):
    if '://' in host:
        host = host.split('://')[1]

    host = host.replace('/', '')
    try:
        remote_ip = socket.gethostbyname(host)
    except Exception as e:
        print(e)
    else:
        return f"IP Address of {host} is {remote_ip}"
