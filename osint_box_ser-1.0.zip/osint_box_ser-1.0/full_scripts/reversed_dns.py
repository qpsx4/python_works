from dns import resolver, reversename
import socket


def reverse(ip):
    try:
        rev_name = reversename.from_address(socket.gethostbyname(ip))
        reversed_dns = str(resolver.resolve(rev_name, "PTR")[0])
    except Exception as e:
        print(e)
    else:
        return reversed_dns
