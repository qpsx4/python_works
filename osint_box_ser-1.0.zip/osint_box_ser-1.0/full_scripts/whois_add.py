from ipwhois import IPWhois
import socket


def who_is(add):
    try:
        domain = IPWhois(socket.gethostbyname(add))
    except Exception as e:
        print(e)
    else:
        if not domain is None:
            res = domain.__dict__
            my_list = []
            for i in res:
                my_list.append(f"{i}: {res[i]}\n")
            return my_list
