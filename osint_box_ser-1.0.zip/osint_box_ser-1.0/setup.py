from distutils.core import setup

setup(
    name='osint_box_ser',
    version='1.0',
    description="OSINT module",
    author='ser',
    author_email='example@eample.com',
    packages=['full_scripts'],
    package_dir={'full_scripts': 'full_scripts'},
    package_data={'full_scripts': ['*.dat']},
)